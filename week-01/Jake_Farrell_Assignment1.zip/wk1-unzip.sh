#!/bin/sh

unzip -q "files.zip"
