#!/bin/sh

find -type f -iname "*.sh"
