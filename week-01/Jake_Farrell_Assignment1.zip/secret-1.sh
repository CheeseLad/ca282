#!/bin/sh

echo "Nobody expects the Spanish Inquisition!" > surprise.txt
