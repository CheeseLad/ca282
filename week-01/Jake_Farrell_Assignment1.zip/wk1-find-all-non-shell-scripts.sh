#!/bin/sh

find -type f -not -name "*.sh"
