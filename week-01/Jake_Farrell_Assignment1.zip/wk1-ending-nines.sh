#!/bin/sh

grep "9"$ $1
