#!/bin/sh

tar -xzf files.tgz
