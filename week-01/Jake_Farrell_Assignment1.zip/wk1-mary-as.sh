#!/bin/sh

grep -w "a" mary.txt
