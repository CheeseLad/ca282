#!/bin/sh

mkdir ./files
tar -xzf files.tgz -C ./files
