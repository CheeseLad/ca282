#!/bin/sh

tr -s $1 " " "\n"
