#!/bin/sh

grep -i "Mary" mary.txt | grep -i "Lamb"
